
# StopWatch
Simple StopWatch App using Kotlin


![WhatsApp Image 2023-07-27 at 8 09 17 AM](https://github.com/nidhirk2020/StopWatch/assets/96578258/21c3a891-f4e3-418f-a314-8f00c1d19dbf)
![stopwatch_ss](https://github.com/nidhirk2020/PRODIGY_AD_03/assets/96578258/13fb076f-1ad3-4633-b661-70ed3bc82190)
